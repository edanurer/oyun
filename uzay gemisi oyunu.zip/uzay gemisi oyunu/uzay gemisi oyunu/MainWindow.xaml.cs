﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using System.Windows.Threading;

namespace uzay_gemisi_oyunu
{
    /// <summary>
    /// MainWindow.xaml etkileşim mantığı
    /// </summary>
    public partial class MainWindow : Window
    {

        DispatcherTimer oyunZamanlayici = new DispatcherTimer();
        bool solaKaydir, sagaKaydir;
        List<Rectangle> ogeSokucu = new List<Rectangle>();
        Random rast = new Random();

        int dusmanruhSayaci = 0;
        int dusmanSayaci = 100;
        int oyuncuHizi = 10;
        int limit = 50;
        int skor = 0;
        int hasar = 0;
        int dusmanHizi = 10;

        Rect oyuncuIsabetKutusu;
        public MainWindow()
        {
            InitializeComponent();

            oyunZamanlayici.Interval = TimeSpan.FromMilliseconds(20);
            oyunZamanlayici.Tick += oyunDongusu;
            oyunZamanlayici.Start();

            tuval.Focus();
            ImageBrush aplan = new ImageBrush();

            aplan.ImageSource = new BitmapImage(new Uri("pack://application:,,,/resimler/purple.png"));
            aplan.TileMode = TileMode.Tile;
            aplan.Viewport = new Rect(0,0, 0.15, 0.15);
            aplan.ViewportUnits = BrushMappingMode.RelativeToBoundingBox;
            tuval.Background = aplan;

            ImageBrush oyuncuResmi = new ImageBrush();
            oyuncuResmi.ImageSource = new BitmapImage(new Uri("pack://application:,,,/resimler/player.png"));
            Oyuncu.Fill = oyuncuResmi;


        }

        private void oyunDongusu(object sender, EventArgs e)
        {
            oyuncuIsabetKutusu = new Rect(Canvas.GetLeft(Oyuncu), Canvas.GetTop(Oyuncu), Oyuncu.Width, Oyuncu.Height);

            dusmanSayaci -= 1;

            PuanTablosu.Content = "Skor: " + skor;
            HasarTablosu.Content = "Hasar: " + hasar;

            if (dusmanSayaci < 0)
            {
                dusmanOlusturma();
                dusmanSayaci = limit;

            }

            if (solaKaydir == true && Canvas.GetLeft(Oyuncu) > 0)
            {
                Canvas.SetLeft(Oyuncu, Canvas.GetLeft(Oyuncu) - oyuncuHizi);

            }
            if (sagaKaydir == true && Canvas.GetLeft(Oyuncu) + 90 < Application.Current.MainWindow.Width)
            {
                Canvas.SetLeft(Oyuncu, Canvas.GetLeft(Oyuncu) + oyuncuHizi);
            }

            foreach (var x in tuval.Children.OfType<Rectangle>())
            {
                if (x is Rectangle && (string)x.Tag == "mermi")
                {
                    Canvas.SetTop(x, Canvas.GetTop(x) - 20);

                    Rect mermiIsabetKutusu = new Rect(Canvas.GetLeft(x), Canvas.GetTop(x), x.Width, x.Height);

                    if (Canvas.GetTop(x) < 10)
                    {
                        ogeSokucu.Add(x);
                    }

                    foreach (var y in tuval.Children.OfType<Rectangle>())
                    {
                        if ( y is Rectangle && (string)y.Tag == "düşman")
                        {
                            Rect dusmanVurusu = new Rect(Canvas.GetLeft(y), Canvas.GetTop(y), y.Width, y.Height);

                            if (mermiIsabetKutusu.IntersectsWith(dusmanVurusu))
                            {
                                ogeSokucu.Add(x);
                                ogeSokucu.Add(y);
                                skor++;
                            }
                        }
                    }
                }

                if (x is Rectangle && (string)x.Tag == "düşman")
                {
                    Canvas.SetTop(x, Canvas.GetTop(x) + dusmanHizi);

                    if (Canvas.GetTop(x) > 750)
                    {
                        ogeSokucu.Add(x);
                        hasar += 10;
                    }

                    Rect dusmanIsabetKutusu = new Rect(Canvas.GetLeft(x), Canvas.GetTop(x), x.Width, x.Height);

                    if (oyuncuIsabetKutusu.IntersectsWith(dusmanIsabetKutusu))
                    {
                        ogeSokucu.Add(x);
                        hasar += 5;
                    }

                }
            }

            foreach (Rectangle i in ogeSokucu)
            {
                tuval.Children.Remove(i);
            }

            if (skor > 5)
            {
                limit = 20;
                dusmanHizi = 15;

            }

            if (hasar > 99)
            {
                oyunZamanlayici.Stop();
                HasarTablosu.Content = "Hasar: 100";
                HasarTablosu.Foreground = Brushes.Red;
                MessageBox.Show(skor + " Düşman uzay gemini yok etti " + Environment.NewLine + "Tekrar oynamak için OK'e bas!", "Uzay Gemisi Kaptanı: ");

                System.Diagnostics.Process.Start(Application.ResourceAssembly.Location);
                Application.Current.Shutdown();
                    
            }

        }

        private void anahtarYukari(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Left)
            {
                solaKaydir = false;
            }
            if (e.Key == Key.Right)
            {
                sagaKaydir = false;
            }

            if (e.Key == Key.Space)
            {
                Rectangle yeniMermi = new Rectangle
                {
                    Tag = "mermi",
                    Height = 20,
                    Width = 5,
                    Fill = Brushes.White,
                    Stroke = Brushes.Red
                };

                Canvas.SetLeft(yeniMermi, Canvas.GetLeft(Oyuncu) + Oyuncu.Width / 2);
                Canvas.SetTop(yeniMermi, Canvas.GetTop(Oyuncu) - yeniMermi.Height);

                tuval.Children.Add(yeniMermi);
            }
        }

        private void anahtarAsagi(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Left)
            {
                solaKaydir = true;
            }
            if (e.Key == Key.Right)
            {
                sagaKaydir = true;
            }
        }

        private void dusmanOlusturma()
        {
            ImageBrush dusmanRuh = new ImageBrush();
            dusmanruhSayaci = rast.Next(1, 5);

            switch (dusmanruhSayaci)
            {
                case 1:
                    dusmanRuh.ImageSource = new BitmapImage(new Uri("pack://application:,,,/resimler/1.png"));
                    break;
                case 2:
                    dusmanRuh.ImageSource = new BitmapImage(new Uri("pack://application:,,,/resimler/2.png"));
                    break;
                case 3:
                    dusmanRuh.ImageSource = new BitmapImage(new Uri("pack://application:,,,/resimler/3.png"));
                    break;
                case 4:
                    dusmanRuh.ImageSource = new BitmapImage(new Uri("pack://application:,,,/resimler/4.png"));
                    break;
                case 5:
                    dusmanRuh.ImageSource = new BitmapImage(new Uri("pack://application:,,,/resimler/5.png"));
                    break;
                   
            }
            
            Rectangle yeniDusman = new Rectangle
            { 
                Tag = "düşman",
                Height = 50,
                Width = 56,
                Fill = dusmanRuh
            };

            Canvas.SetTop(yeniDusman, -100);
            Canvas.SetLeft(yeniDusman, rast.Next(30, 430));
            tuval.Children.Add(yeniDusman);

        }
    }
}
